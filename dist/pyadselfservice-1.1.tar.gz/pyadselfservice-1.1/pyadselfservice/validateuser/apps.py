from django.apps import AppConfig


class ValidateuserConfig(AppConfig):
    name = 'validateuser'
